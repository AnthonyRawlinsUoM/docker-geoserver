OGR2OGR based output format
===========================

The installation requires a working ogr2ogr utility in the system path,
and to drop the jars contained in this zip file into your GeoServer
installation, geoserver/WEB-INF/lib

For more information consult the user guide at docs.geoserver.org, 
in particular in the extensions section.
